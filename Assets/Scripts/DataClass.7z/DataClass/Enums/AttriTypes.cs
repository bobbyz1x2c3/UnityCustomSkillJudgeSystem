﻿namespace DataClass.Enums
{
    public enum AttriTypes
    {
        HP,
        maxHP,
        Postur,
        stamina ,
        MaxStamina ,
        MP ,
        maxMP,
        atk ,
        arm ,
        spd ,
        mag 
    }
}