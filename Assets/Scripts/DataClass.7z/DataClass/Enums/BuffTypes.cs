﻿namespace DataClass.Enums
{
    public enum BuffTypes
    {
        atk_down_10p,
        atk_up_10p,
        atk_down_10,
        atk_up_10,
        arm_down_10p,
        arm_up_10p,
        arm_down_10,
        arm_up_10,
        mag_down_10p,
        mag_up_10p,
        mag_down_10,
        mag_up_10,
        spd_down_10,
        spd_up_10
    }
}