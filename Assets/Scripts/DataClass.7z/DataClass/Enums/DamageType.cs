﻿namespace DataClass.Enums
{
    public enum DamageType
    {
        Physics,
        Magic
    }
}