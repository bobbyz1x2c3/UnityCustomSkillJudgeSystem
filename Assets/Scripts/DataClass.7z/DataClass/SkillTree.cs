using System.Collections;
using System.Collections.Generic;
using DataClass.test;
using UnityEngine;

public class SkillTree : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
