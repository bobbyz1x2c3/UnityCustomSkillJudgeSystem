﻿using System.Collections.Generic;
using DataClass.Effection;
using DataClass.Enums;
using Unity.Netcode;
using UnityEngine;

namespace DataClass.Skills
{
    public class CustomSkill : SkillBase
    {

        public CustomSkill()
        {
            effects = new List<EffectBase>();
        }
        public void AddDamage(EntityProps entity,float _baseValue, float _coeffValue , float _pierceCoeff = 1,float _pierceBase = 0,DamageType _damageType = DamageType.Physics,AttriTypes _attriType = AttriTypes.atk)
        {
            var d = new DamageCause(entity, _baseValue, _coeffValue, _pierceCoeff, _pierceBase, _damageType, _attriType);
            effects.Add(d);
        }

        public void AddBuff(EntityProps entity, BuffTypes _type, float _lastTime)
        {
            effects.Add(new BuffCause(entity,_lastTime, _type));
        }

        public void AddPostureReduce(float _coeff)
        {
            effects.Add(new PostureReduce(_coeff));
        }
    }
}