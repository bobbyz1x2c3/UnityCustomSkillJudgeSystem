﻿using System;
using DataClass.Enums;
using DataClass.Structs;
using Unity.Netcode;

namespace DataClass
{
    public struct Buff : INetworkSerializeByMemcpy,IEquatable<Buff>
    {
        public BuffTypes Type;
        public float lastTime;
        public ulong propFromID;

        public bool Equals(Buff other)
        {
            return (Type == other.Type && propFromID == other.propFromID);
        }
    }
}